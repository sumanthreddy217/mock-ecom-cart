export const products = [
  { id: 1, name: "Wireless Headphones", price: 99.99, image: "https://via.placeholder.com/150" },
  { id: 2, name: "Smart Watch", price: 149.99, image: "https://via.placeholder.com/150" },
  { id: 3, name: "Gaming Mouse", price: 59.99, image: "https://via.placeholder.com/150" },
  { id: 4, name: "Mechanical Keyboard", price: 129.99, image: "https://via.placeholder.com/150" },
  { id: 5, name: "USB-C Hub", price: 39.99, image: "https://via.placeholder.com/150" },
];
